const { Pool } = require('pg');

let connPg = function () {
  const pgConfig = {
    user: 'BD2313026',
    password: 'BD2313026',
    database: 'BD',
    host: 'APOLO',
    port: 5432,
    ssl: false,
  };

  return new Pool(pgConfig); // Retorna a conexão com o banco
};

module.exports = function () {
  return connPg;
};
